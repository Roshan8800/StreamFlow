
DROP TABLE content_analytics;
DROP TABLE content_tags;
DROP TABLE content_submissions;
DROP TABLE external_links;
DROP TABLE video_embeds;
