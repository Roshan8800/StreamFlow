
-- Remove sample data
DELETE FROM subscription_plans;
DELETE FROM videos;
DELETE FROM categories;
